# Entregable colores Diseño de Interfaces Web
 ## Autor: Ana María Herrera Sánchez
 ### Justificación: Para la página Web Amarthe se ha elegido la siguiente paleta de colores blanco, negro, gris claro y caldera. Estos colores se han seleccionado cuidadosamente para la página web de Amarthe con el objetivo de transmitir una estética limpia, elegante y contemporánea, que refleja la visión de la marca como un referente de vanguardia en el sector de la moda. Cada color ha sido pensado para desempeñar un papel específico en la narrativa visual de Amarthe, contribuyendo a la coherencia y a la identidad de la marca en línea con las expectativas de sus clientes y seguidores. 
 **Colores** ![](capturaColores.png)
 **Fichero HTML** 
 ```
 <!DOCTYPE html>
<html>
  <head>
    <title>Colores de diseño Web Amarthe</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="author" content="Ana María Herrera Sánchez" />
    <link rel="stylesheet" type="text/css" href="color.css" />
  </head>
  <body>
    <h1>Colores de Diseño Web Amarthe</h1>
    <table class="color-table">
      <tbody>
        <tr>
          <th>Color Primario:</th>
		  <th>Color Secundario 1:</th>
		  <th>Color Secundario 2:</th>
		  <th>Color acento:</th>
        </tr>
        <tr>
			<td class="primary-1">
			<div class="black">#FFFFFF</div>
			</td>
          	<td class="secondary-1">
            <div class="white">#000000</div>
          </td>
		  <td class="secondary-2">
            <div class="black">#FFFFFF</div>
          </td>
		  <td class="complement-1">
            <div class="white">#FFFFFF</div>
          </td>
        </tr>
       
      </tbody>
    </table>
    <hr />
  </body>
</html>
 ```
 

BLANCO : El blanco como color base junto al negro, se utiliza como color de fondo principal en los bloques de elementos para dar una sensación de amplitud y limpieza en la página. Además, el blanco es un color asociado con la pureza y la simplicidad, lo que refuerza la sensación de confianza y claridad en la marca Amarthe. Además, al tratarse de una página relacionada con el mundo de la moda y con imágenes que contendrán multitud de colores, se considera que el blanco y el negro deben ser los colores base que armonizan con el resto de la gama cromática, cualquiera que sea.

#FFFFFF

NEGRO : El negro se emplea para crear un fuerte contraste con el blanco y resaltar elementos importantes, como el texto o los fondos. El negro también aporta sofisticación y elegancia al diseño, lo que es especialmente relevante para una marca que busca proyectar una imagen de alta calidad y estilo.

#000000

GRIS CLARO : El gris claro, representado por el color hexadecimal #DCD5D5, se utiliza para agregar sutileza y equilibrio en el diseño. Este tono de gris actúa como un fondo adicional en algunas áreas de la página, sobre todo en la principal, lo que ayuda a destacar el contenido principal y a suavizar el contraste entre el blanco y el negro. El gris claro también proporciona un toque de neutralidad y modernidad.

#DCD5D5

CALDERA : El color 'caldera' se ha incorporado para inyectar energía y personalidad a la paleta de colores. Este tono más cálido pero intenso puede utilizarse para acentuar áreas específicas de la página, como acentos de diseño o elementos destacados tales como botones que llaman a la acción como el Suscribe. El color 'caldera' añade un toque de vitalidad y atractivo visual, que puede ser especialmente útil para resaltar información relevante y captar la atención del usuario. Además creará puentes de color hacia las imágenes. 

#DE1515

#

``` 
**FICHERO CSS**
 ``` /* PALETA DE COLORES WEB */

.primary-1 {
	 background-color: #FFFFFF;
	 width: 200px;
	 height: 200px;
	 }
.secondary-1 { 
	background-color: #000000;
	width: 200px;
	height: 200px;
}
.secondary-2 { 
	background-color: #DCD5D5;
	width: 200px;
	height: 200px;
}
.complement-1 {
	 background-color: #DE1515;
	 width: 200px;
	 height: 200px;
	 }

body {
	margin:0; padding: 2em;
	background: #fff;
	color: #000;
	font: 12px/1.33 "Segoe UI", "Helvetica Neue", Helvetica, sans-serif;
	text-align:center;
	}
h1 {
	margin: 0.5em 0;
	font-size: 200%;
	}
p {
	margin: 0.5em 0;
	}

.color-table {
	margin: 2em 2em 5em;
	font-size:100%;
	border:collapse;
	border: none
	}
.color-table th {
	padding: 0 1em 0 0;
	text-align: right;
	vertical-align: middle;
	font-size: 100%;
	font-weight: normal;
	
	}

	.color-table td {
		padding: 0 1em 0 0;
		text-align: right;
		vertical-align: middle;
		font-size: 100%;
		font-weight: normal;
		border: 1px solid black;
		}

.color-table .white { margin-bottom:0.2em; color:white }
.color-table .black { margin-top:0.2em; color:black }

hr {
	margin: 2em 0 1em 0;
	border:none;
	border-bottom:1px solid silver;
	} 
	``` 

 